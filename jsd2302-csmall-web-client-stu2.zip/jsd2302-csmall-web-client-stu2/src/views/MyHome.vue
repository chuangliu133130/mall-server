<template>
    <div>


        <el-container>
            <el-header class="el-header">
                <div class="login-user">
                    <span class="logo"> 酷鲨商城运营管理平台</span>


                    <input class="avator" type="button" @click="avator()">
                    <span class="welcome"> 欢迎回来,root</span>

                </div>
            </el-header>

            <el-container class="layout-body">

                <el-aside class="el-aside" style="background-color:#222 ; ">


                    <el-menu
                        router
                        :default-active="activeMenuItemPath"
                        class="el-menu-vertical-demo"
                        background-color="#222"
                        text-color="#fff"
                        active-text-color="#fff" style="overflow: hidden">


                        <el-menu-item  index="/sys-admin/album" class="el-menu-item">
                            <i class="el-icon-s-home"></i>
                            首页
                        </el-menu-item>
                        <!-- 临时界面 -->
                         <el-submenu class="el-submenu" index="2">
                            <template slot="title">
                                <i class="el-icon-s-tools"></i>
                                <span>临时页面</span>
                            </template>
                            <el-menu-item class="el-menu-item" index="/sys-admin/adminlist">
                                <i class="el-icon-circle-plus"></i>
                                <span>添加管理员</span>
                            </el-menu-item>
<!--                            <el-menu-item class="el-menu-item" index="/sys-admin/temp/admin/list">-->
<!--                                <i class="el-icon-s-operation"></i>-->
<!--                                <span>管理员列表</span>-->
<!--                            </el-menu-item>-->
                            <el-menu-item class="el-menu-item" index="/sys-admin/temp/brand/add-new">
                                <i class="el-icon-circle-plus"></i>
                                <span>添加品牌</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="/sys-admin/temp/brand/list">
                                <i class="el-icon-s-operation"></i>
                                <span>品牌列表</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="/sys-admin/temp/category/add-new">
                                <i class="el-icon-circle-plus"></i>
                                <span>添加类别</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="/sys-admin/temp/category/list">
                                <i class="el-icon-s-operation"></i>
                                <span>类别列表</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="/sys-admin/albumlist">
                                <i class="el-icon-circle-plus"></i>
                                <span>添加相册</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="/sys-admin/temp/album/list">
                                <i class="el-icon-s-operation"></i>
                                <span>相册列表</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="/sys-admin/temp/attribute-template/add-new">
                                <i class="el-icon-circle-plus"></i>
                                <span>添加属性模板</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="/sys-admin/temp/attribute-template/list">
                                <i class="el-icon-s-operation"></i>
                                <span>属性模板列表</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="/sys-admin/temp/attribute/add-new">
                                <i class="el-icon-circle-plus"></i>
                                <span>添加属性</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="/sys-admin/temp/attribute/list">
                                <i class="el-icon-s-operation"></i>
                                <span>属性列表</span>
                            </el-menu-item>
                        </el-submenu>


                        <!-- 商品管理 -->
                         <el-submenu  class="el-submenu"  index="3">
                            <template slot="title">
                                <i class="el-icon-s-goods"></i>
                                <span>商品管理</span>
                            </template>
                            <el-menu-item class="el-menu-item" index="3-1" disabled>
                                <i class="el-icon-s-grid"></i>
                                <span slot="title">SPU台账</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="/sys-admin/product/spu/add-new-1">
                                <i class="el-icon-circle-plus"></i>
                                <span slot="title">新增SPU</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="3-3" disabled>
                                <i class="el-icon-picture"></i>
                                <span slot="title">相册管理</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="3-4" disabled>
                                <i class="el-icon-s-unfold"></i>
                                <span slot="title">商品类别</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="3-5" disabled>
                                <i class="el-icon-s-flag"></i>
                                <span slot="title">属性模板</span>
                            </el-menu-item>
                            <el-menu-item class="el-menu-item" index="3-6" disabled>
                                <i class="el-icon-s-data"></i>
                                <span slot="title">品牌管理</span>
                            </el-menu-item>
                        </el-submenu>
                    </el-menu>


                </el-aside>
                <el-main class="el-main">
                    <router-view></router-view>
<!--                    main666-->
                </el-main>
            </el-container>

        </el-container>


    </div>
</template>
<script>
export default {
    data() {
        return {
            activeMenuItemPath:"",
            ruleForm: {
                username: 'root',
                password: '123456'
            },
            rules: {
                username: [
                    {required: true, message: '请输入用户名', trigger: 'blur'},
                    {min: 4, max: 15, message: '长度在 4 到 15 个字符', trigger: 'blur'}
                ],
                password: [
                    {required: true, message: '请输入密码', trigger: 'blur'},
                    {min: 4, max: 15, message: '长度在 4 到 15 个字符', trigger: 'blur'}
                ]
            }
        };
    },
    methods: {
        avator() {
            alert(1111)
        },
        submitForm(formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    let url = 'http://localhost:9081/admins/login';
                    console.log('url = ' + url);

                    let formData = this.qs.stringify(this.ruleForm);
                    console.log('formData = ' + formData);

                    this.axios.post(url, formData).then((response) => {
                        let responseBody = response.data;
                        console.log(responseBody);
                        if (responseBody.state == 20000) {
                            this.$message({
                                showClose: true,
                                message: '登录成功！',
                                type: 'success'
                            });
                            let jwt = responseBody.data;
                            console.log('jwt = ' + jwt);
                            localStorage.setItem('jwt', jwt);
                            console.log('已经将JWT存入到localStorage中，即将跳转页面……');
                            this.$router.push('/');
                        } else {
                            this.$message({
                                showClose: true,
                                message: responseBody.message,
                                type: 'error'
                            });
                        }
                    });
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });
        },
        resetForm(formName) {
            this.$refs[formName].resetFields();
        }
    },
    mounted() {
        let path = this.$router.currentRoute.path;
        if (path.startsWith('/sys-admin/product/spu/add-new-')) {
            path = '/sys-admin/product/spu/add-new-1';
        }
        if (path.startsWith('/sys-admin/album')) {
            path = '/sys-admin/albumlist';
        }
        this.activeMenuItemPath = path;
    }
}
</script>

<style>

.logo {
    line-height: 60px;
    color: white;
    font-weight: bold;
    font-size: 29px;
}


.el-header {
    background-color: #1684b0;
}

.el-main {

}

.el-aside {

}

.welcome {
    /*position: absolute;*/
    float: right;
    margin-right: 20px;
    line-height: 60px;
    color: white;
}

.login-user {
    width: 100%;
    margin: 0 0;
    padding: 0;
}

.avator {
    width: 40px;
    height: 40px;
    border-radius: 20px;
    margin-top: 10px;
    background-color: #aaaaaa;
    border: 0;

    float: right;
    margin-right: 10px;
    line-height: 60px;
}

.layout-body {
    position: absolute;
    top: 60px;
    bottom: 0;
    left: 0;
    right: 0;

}
.el-menu-item{
    width: 300px !important;
}

.el-submenu{
    width: 300px !important;
}

</style>
<!--<template>-->
<!--    <div>-->
<!--        &lt;!&ndash; 外层容器 &ndash;&gt;-->
<!--        <el-container>-->
<!--            &lt;!&ndash; 上半区域：顶栏 &ndash;&gt;-->
<!--            <el-header class="layout-header">-->
<!--                <h1>酷鲨商城运营管理平台</h1>-->
<!--            </el-header>-->
<!--            &lt;!&ndash; 下半区域 &ndash;&gt;-->
<!--            <el-container class="layout-body">-->
<!--                &lt;!&ndash; 下半区域的左侧边栏 &ndash;&gt;-->
<!--                <el-aside class="layout-aside">-->
<!--                    <el-menu-->
<!--                            router-->
<!--                            :default-active="activeMenuItemPath"-->
<!--                            class="el-menu-vertical-demo"-->
<!--                            background-color="#222"-->
<!--                            text-color="#fff"-->
<!--                            active-text-color="#fff">-->
<!--                        &lt;!&ndash; 首页 &ndash;&gt;-->
<!--                        <el-menu-item index="/sys-admin/album">-->
<!--                            <i class="el-icon-s-home"></i>-->
<!--                            <span>首页</span>-->
<!--                        </el-menu-item>-->
<!--                        &lt;!&ndash; 临时页面 &ndash;&gt;-->
<!--                        <el-submenu index="1">-->
<!--                            <template slot="title">-->
<!--                                <i class="el-icon-s-tools"></i>-->
<!--                                <span>临时页面</span>-->
<!--                            </template>-->
<!--                            <el-menu-item index="/sys-admin/temp/admin/add-new">-->
<!--                                <i class="el-icon-circle-plus"></i>-->
<!--                                <span>添加管理员</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/admin/list">-->
<!--                                <i class="el-icon-s-operation"></i>-->
<!--                                <span>管理员列表</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/brand/add-new">-->
<!--                                <i class="el-icon-circle-plus"></i>-->
<!--                                <span>添加品牌</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/brand/list">-->
<!--                                <i class="el-icon-s-operation"></i>-->
<!--                                <span>品牌列表</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/category/add-new">-->
<!--                                <i class="el-icon-circle-plus"></i>-->
<!--                                <span>添加类别</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/category/list">-->
<!--                                <i class="el-icon-s-operation"></i>-->
<!--                                <span>类别列表</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/album/add-new">-->
<!--                                <i class="el-icon-circle-plus"></i>-->
<!--                                <span>添加相册</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/album/list">-->
<!--                                <i class="el-icon-s-operation"></i>-->
<!--                                <span>相册列表</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/attribute-template/add-new">-->
<!--                                <i class="el-icon-circle-plus"></i>-->
<!--                                <span>添加属性模板</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/attribute-template/list">-->
<!--                                <i class="el-icon-s-operation"></i>-->
<!--                                <span>属性模板列表</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/attribute/add-new">-->
<!--                                <i class="el-icon-circle-plus"></i>-->
<!--                                <span>添加属性</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/temp/attribute/list">-->
<!--                                <i class="el-icon-s-operation"></i>-->
<!--                                <span>属性列表</span>-->
<!--                            </el-menu-item>-->
<!--                        </el-submenu>-->
<!--                        &lt;!&ndash; 商品管理 &ndash;&gt;-->
<!--                        <el-submenu index="3">-->
<!--                            <template slot="title">-->
<!--                                <i class="el-icon-s-goods"></i>-->
<!--                                <span>商品管理</span>-->
<!--                            </template>-->
<!--                            <el-menu-item index="3-1" disabled>-->
<!--                                <i class="el-icon-s-grid"></i>-->
<!--                                <span slot="title">SPU台账</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="/sys-admin/product/spu/add-new-1">-->
<!--                                <i class="el-icon-circle-plus"></i>-->
<!--                                <span slot="title">新增SPU</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="3-3" disabled>-->
<!--                                <i class="el-icon-picture"></i>-->
<!--                                <span slot="title">相册管理</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="3-4" disabled>-->
<!--                                <i class="el-icon-s-unfold"></i>-->
<!--                                <span slot="title">商品类别</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="3-5" disabled>-->
<!--                                <i class="el-icon-s-flag"></i>-->
<!--                                <span slot="title">属性模板</span>-->
<!--                            </el-menu-item>-->
<!--                            <el-menu-item index="3-6" disabled>-->
<!--                                <i class="el-icon-s-data"></i>-->
<!--                                <span slot="title">品牌管理</span>-->
<!--                            </el-menu-item>-->
<!--                        </el-submenu>-->
<!--                        &lt;!&ndash; 订单管理 &ndash;&gt;-->
<!--                        <el-submenu index="4" disabled>-->
<!--                            <template slot="title">-->
<!--                                <i class="el-icon-s-order"></i>-->
<!--                                <span>订单管理</span>-->
<!--                            </template>-->
<!--                        </el-submenu>-->
<!--                        &lt;!&ndash; 营销管理 &ndash;&gt;-->
<!--                        <el-submenu index="5" disabled>-->
<!--                            <template slot="title">-->
<!--                                <i class="el-icon-s-ticket"></i>-->
<!--                                <span>营销管理</span>-->
<!--                            </template>-->
<!--                        </el-submenu>-->
<!--                        &lt;!&ndash; 商家管理 &ndash;&gt;-->
<!--                        <el-submenu index="6" disabled>-->
<!--                            <template slot="title">-->
<!--                                <i class="el-icon-s-shop"></i>-->
<!--                                <span>商家管理</span>-->
<!--                            </template>-->
<!--                        </el-submenu>-->
<!--                        &lt;!&ndash; 权限管理 &ndash;&gt;-->
<!--                        <el-submenu index="7" disabled>-->
<!--                            <template slot="title">-->
<!--                                <i class="el-icon-s-check"></i>-->
<!--                                <span>权限管理</span>-->
<!--                            </template>-->
<!--                        </el-submenu>-->
<!--                    </el-menu>-->
<!--                </el-aside>-->
<!--                &lt;!&ndash; 下半区域的右侧主体 &ndash;&gt;-->
<!--                <el-main class="layout-main">-->
<!--                    &lt;!&ndash; 由其它视图来显示 &ndash;&gt;-->
<!--                    <router-view/>-->
<!--                </el-main>-->
<!--            </el-container>-->
<!--        </el-container>-->
<!--    </div>-->
<!--</template>-->

<!--<style>-->
<!--.layout-header {-->
<!--    background: #1684b0;-->
<!--}-->

<!--.layout-header h1 {-->
<!--    color: #fff;-->
<!--    line-height: 60px;-->
<!--}-->

<!--.layout-body {-->
<!--    position: absolute;-->
<!--    top: 60px;-->
<!--    bottom: 0;-->
<!--    left: 0;-->
<!--    right: 0;-->
<!--}-->

<!--.layout-aside {-->
<!--    background: #222;-->
<!--}-->
<!--.layout-aside .el-menu{-->
<!--    border: 0;-->
<!--}-->
<!--.layout-aside i {-->
<!--    color: #fff !important;-->
<!--}-->

<!--.layout-main {-->
<!--    background: #fff;-->
<!--}-->

<!--.el-menu-item.is-active {-->
<!--    background: #2d3c4d !important;-->
<!--}-->
<!--</style>-->

<!--<script>-->
<!--export default {-->
<!--    data() {-->
<!--        return {-->
<!--            activeMenuItemPath: ''-->
<!--        }-->
<!--    },-->
<!--    mounted() {-->
<!--        let path = this.$router.currentRoute.path;-->
<!--        if (path.startsWith('/sys-admin/product/spu/add-new-')) {-->
<!--            path = '/sys-admin/product/spu/add-new-1';-->
<!--        }-->
<!--        this.activeMenuItemPath = path;-->
<!--    }-->
<!--}-->
<!--</script>-->