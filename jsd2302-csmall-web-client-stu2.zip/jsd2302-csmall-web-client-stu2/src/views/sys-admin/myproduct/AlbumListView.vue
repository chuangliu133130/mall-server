<template>
    <div>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="font-size: 16px;">
            <el-breadcrumb-item :to="{ path: '/' }">
                <i class="el-icon-s-promotion"></i> 后台管理
            </el-breadcrumb-item>
            <el-breadcrumb-item>相册管理</el-breadcrumb-item>
        </el-breadcrumb>
        <el-divider></el-divider>

        <div style="margin-bottom: 20px;">
            <el-button type="primary" size="medium"
                       @click="$router.push('/sys-admin/album')">添加相册
            </el-button>
        </div>

        <el-table :data="tableData" border style="width: 100%">
            <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
            <el-table-column prop="name" label="名称" width="180" header-align="center"
                             show-overflow-tooltip></el-table-column>
            <el-table-column prop="description" label="简介" header-align="center"
                             show-overflow-tooltip></el-table-column>
            <el-table-column prop="sort" label="排序序号" width="100" align="center"></el-table-column>
            <el-table-column label="查看图片" width="100" align="center">
                <el-button size="mini">查看</el-button>
            </el-table-column>
            <el-table-column label="操作" width="100" align="center">
                <template slot-scope="scope">
                    <el-button type="primary" icon="el-icon-edit" circle size="mini"
                               @click="openEditDialog(scope.row)"></el-button>                    <el-button type="danger" size="mini" icon="el-icon-delete" circle
                               @click="openDeleteConfirm(scope.row)"></el-button>
                </template>
            </el-table-column>
        </el-table>

        <div style="text-align: right; margin: 10px auto;">
            <el-pagination
                @current-change="changePage"
                layout="total, prev, pager, next"
                :total="total"
                :current-page="currentPage"
                :page-size="pageSize">
            </el-pagination>
        </div>


        <!-- 修改相册的弹出表单Dialog -->
        <el-dialog id="myModel" title="编辑相册" :visible.sync="dialogFormVisible">
            <el-form :model="editForm">
                <el-form-item label="名称" :label-width="formLabelWidth">
                    <el-input v-model="editForm.name" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="简介" :label-width="formLabelWidth">
                    <el-input v-model="editForm.description" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="排序序号" :label-width="formLabelWidth">
                    <el-input v-model="editForm.sort" autocomplete="off"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="submitEditForm()">确 定</el-button>
            </div>
        </el-dialog>

    </div>
</template>

<script>
export default {
    data() {
        return {
            selectedEditAlbum:"",
            page:"1",
            // 表格数据
            tableData: [],
            // 分页相关数据
            currentPage: this.$router.currentRoute.query.page ? parseInt(this.$router.currentRoute.query.page) : 1,
            pageSize: 20,
            pageCount: 1,
            total: 0,
            // 编辑对话框的可见性
            dialogFormVisible: false,
            // 编辑表单
            editForm: {
                id: '',
                name: '',
                description: '',
                sort: ''
            },
            // 编辑表单的label宽度
            formLabelWidth: '120px'
        }
    },
    methods: {
        submitEditForm(){

            let url = 'http://localhost:8888/album/update?id='+this.editForm.id;
            console.log('url = ' + url);
            let formData = this.qs.stringify(this.editForm);
            console.log('formData = ' + formData);

            this.axios
                .post(url,formData).then((response) => {
                let jsonResult = response.data;
                if (jsonResult.state == 20000) {
                    this.$message({
                        message: '修改相册成功！',
                        type: 'success'
                    });
                    this.loadAlbumList();
                    this.dialogFormVisible = false;
                } else if (jsonResult.state == 40400) {
                    this.$alert(jsonResult.message, '警告', {
                        confirmButtonText: '确定',
                        callback: action => {
                            this.dialogFormVisible = false;
                            this.loadAlbumList();
                        }
                    });
                } else {
                    this.$message.error(jsonResult.message);
                }
            });
        },
        openEditDialog(album) {

            this.selectedEditAlbum = album;
            this.dialogFormVisible = true;
            this.editForm = album;
            this.editForm= album;
            // let url = 'http://localhost:9080/albums/' + album.id;
            // console.log('url = ' + url);
            // let loginInfo = JSON.parse(localStorage.getItem('loginInfo'));
            // this.axios
            //     .create({'headers': {'Authorization': loginInfo.token}})
            //     .get(url).then((response) => {
            //     let jsonResult = response.data;
            //     if (jsonResult.state == 20000) {
            //         this.dialogFormVisible = true;
            //         this.editForm = jsonResult.data;
            //     } else {
            //         this.$alert(jsonResult.message, '警告', {
            //             confirmButtonText: '确定',
            //             callback: action => {
            //                 this.loadAlbumList();
            //             }
            //         });
            //     }
            // });
        },



        openDeleteConfirm(album) {
            this.$confirm('此操作将永久删除【' + album.id + '-' + album.name + '】相册，是否继续？', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.handleDelete(album);
            }).catch(() => {
            });
        },
        handleDelete(album) {

            let url = 'http://localhost:8888/album/delete';
            console.log('url = ' + url);

            let formData = 'albumId=' + album.id;
            console.log('formData = ' + formData);

            this.axios.post(url, formData).then((response) => {
                let jsonResult = response.data;
                if (jsonResult.state == 20000) {
                    this.$message({
                        message: '删除相册成功！',
                        type: 'success'
                    });
                    this.loadAlbumList();
                } else if (jsonResult.state == 40400) {
                    this.$alert(jsonResult.message, '错误', {
                        confirmButtonText: '确定',
                        callback: action => {
                            this.loadAlbumList();
                        }
                    });
                } else if (jsonResult.state == 40900) {
                    this.$alert(jsonResult.message, '错误', {
                        confirmButtonText: '确定',
                        callback: action => {
                        }
                    });
                }
            });
        },
        changePage(value) {
            this.page = value;
            this.$router.replace('?page=' + value);
            this.loadAlbumList();

        },
        loadAlbumList() {
            // let page = this.$router.currentRoute.query.page;
           let page = this.page;
            if (!page) {
                page = 1;
            }

            let url = 'http://localhost:8888/album/list?page=' + page;
            console.log('url = ' + url);

            this.axios.get(url).then((response) => {
                let jsonResult = response.data;

                if (jsonResult.state == 20000) {
                    this.tableData = jsonResult.data.list;
                    this.total = jsonResult.data.total;
                    this.pageSize = jsonResult.data.pageSize;
                    this.currentPage = jsonResult.data.currentPage;
                } else {
                    this.$alert(jsonResult.message, '错误', {
                        confirmButtonText: '确定',
                        callback: action => {
                        }
                    });
                }
            });
        }
    },
    mounted() {
        this.loadAlbumList();
    }
}
</script>