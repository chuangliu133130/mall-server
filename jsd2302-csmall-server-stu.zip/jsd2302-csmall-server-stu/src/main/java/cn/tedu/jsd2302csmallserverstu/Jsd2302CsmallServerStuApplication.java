package cn.tedu.jsd2302csmallserverstu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jsd2302CsmallServerStuApplication {

    public static void main(String[] args) {
        SpringApplication.run(Jsd2302CsmallServerStuApplication.class, args);
    }

}
