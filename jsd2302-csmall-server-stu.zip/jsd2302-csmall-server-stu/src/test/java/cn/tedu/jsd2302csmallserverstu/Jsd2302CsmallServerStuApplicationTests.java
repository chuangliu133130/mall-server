package cn.tedu.jsd2302csmallserverstu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jsd2302CsmallServerStuApplicationTests {

    @Test
    void contextLoads() {
    }

}
