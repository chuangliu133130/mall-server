package cn.tedu.csmall.apassport;

import cn.tedu.csmall.apassport.mapper.AdminMapper;
import cn.tedu.csmall.apassport.mapper.AdminRoleMapper;
import cn.tedu.csmall.apassport.pojo.entity.Admin;
import cn.tedu.csmall.apassport.pojo.entity.AdminRole;
import cn.tedu.csmall.apassport.pojo.param.AdminAddNewParam;
import cn.tedu.csmall.apassport.service.IAdminService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@SpringBootTest
class CsmallApassportApplicationTests {
@Autowired
    AdminMapper adminMapper;

@Autowired
    IAdminService iAdminService;

@Autowired
    AdminRoleMapper adminRoleMapper;

    @Test
    void batchadmin() {
        AdminAddNewParam adminAddNewParam = new AdminAddNewParam();
        adminAddNewParam.setUsername("达内老师6666");
        adminAddNewParam.setPassword("password111666");
        adminAddNewParam.setNickname("teacher1");
        adminAddNewParam.setPhone("13100000000");
        adminAddNewParam.setEmail("aaa@126.com");
        adminAddNewParam.setDescription("教学java");
        adminAddNewParam.setEnable(1L);
        adminAddNewParam.setAvatar("aava");
        adminAddNewParam.setRoleIds(new Long[]{1L,2L});
        iAdminService.batchNewAdmin(adminAddNewParam);

    }
    @Test
    void batch() {
        List<AdminRole> alist = new ArrayList<>();
        for (Long i = 0L; i < 10; i++) {
            AdminRole adminRole = new AdminRole();
            adminRole.setAdminId(i + 60);
            adminRole.setRoleId(i+60);
            adminRole.setGmtCreate(LocalDateTime.now());
            adminRole.setGmtModified(LocalDateTime.now());
            alist.add(adminRole);
            adminRoleMapper.insertBatch(alist);
        }
    }
    @Test
    void contextLoads() {
    }
    @Test
    void b() {

        AdminAddNewParam adminAddNewParam = new AdminAddNewParam();
        adminAddNewParam.setUsername("DaNei999888--");
        adminAddNewParam.setRoleIds( new Long[]{2L,9L});
        iAdminService.addNewAdmin(adminAddNewParam);





    }
    @Test
    void a() {
        Admin admin = new Admin();
        admin.setNickname("DaNei999888");
        admin.setUsername("DaNei999888-000");
        adminMapper.insert(admin);
    }
}
