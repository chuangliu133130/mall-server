/*Table structure for table `mt_user` */

DROP TABLE IF EXISTS `mt_user`;

CREATE TABLE `mt_user` (
                           `id` int NOT NULL AUTO_INCREMENT COMMENT '会员ID',
                           `name` varchar(255) DEFAULT '' COMMENT '会员姓名',
                           `area` varchar(50) DEFAULT '' COMMENT '国家/地区',
                           `phone` varchar(255) DEFAULT '' COMMENT '手机号码',

                           `gender` int DEFAULT '0' COMMENT '性别 0男；1女',
                           `birthday` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT  '' COMMENT '出生日期',
                           `address` varchar(100) DEFAULT '' COMMENT '地址',
                           `join_time` datetime DEFAULT NULL COMMENT '会员开始时间',

                           `store_id` int NOT NULL  COMMENT '商铺ID',
                           `consum` decimal(10,2)  COMMENT '消费金额',
                           `number` int NOT NULL  COMMENT '消费次数',
                           `consume_time` datetime DEFAULT NULL COMMENT '上次消费时间',
                           `note` varchar(100) DEFAULT '' COMMENT '备注',




                           `avator` varchar(255) DEFAULT '' COMMENT '头像',
                           `id_card` varchar(20) DEFAULT '' COMMENT '证件号码',
                           `grade_id` varchar(10) DEFAULT '1' COMMENT '等级ID',
                           `start_time` datetime DEFAULT NULL COMMENT '会员开始时间',
                           `end_time` datetime DEFAULT NULL COMMENT '会员结束时间',
                           `balance` float(10,2) DEFAULT '0.00' COMMENT '余额',
  `point` int DEFAULT '0' COMMENT '积分',
  `password` varchar(32) DEFAULT '' COMMENT '密码',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `status` char(1) DEFAULT 'A' COMMENT '状态，A：激活；N：禁用；D：删除',
  `description` varchar(255) DEFAULT '' COMMENT '备注信息',
  `operator` varchar(30) DEFAULT '' COMMENT '最后操作人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8 COMMENT='会员个人信息';