DROP TABLE IF EXISTS pms_sku;
CREATE TABLE pms_sku
(
    id                     bigint(20) unsigned NOT NULL COMMENT '数据id',
    name                  varchar(255)        DEFAULT NULL COMMENT '名字',
    pinyin                  varchar(255)        DEFAULT NULL COMMENT '名字',
    bar_code               varchar(255)        DEFAULT NULL COMMENT '条型码',
    category_id            bigint(20) unsigned DEFAULT NULL COMMENT '分类id',

    spu_id                 bigint(20) unsigned DEFAULT NULL COMMENT '规格SPU id',
    brand_id            bigint(20) unsigned DEFAULT NULL COMMENT '品牌id',
    supplier_id            bigint(20) unsigned DEFAULT NULL COMMENT '供应商id',
     album_id               bigint(20) unsigned DEFAULT NULL COMMENT '相册id',
    pictures               varchar(1000)        DEFAULT NULL COMMENT '组图URLs，使用JSON格式表示',
    last_day            datetime            DEFAULT NULL COMMENT '过期时间',
    price                  decimal(10, 2)      DEFAULT NULL COMMENT '单价',
    animal_type                  decimal(10, 2)      DEFAULT NULL COMMENT '单价',

    stock                  int(10) unsigned    DEFAULT NULL COMMENT '当前库存',
    stock_threshold        int(10) unsigned    DEFAULT NULL COMMENT '库存预警阈值',
    sales                  int(10) unsigned    DEFAULT NULL COMMENT '销量（冗余）',
    comment_count          int(10) unsigned    DEFAULT NULL COMMENT '买家评论数量总和（冗余）',
    positive_comment_count int(10) unsigned    DEFAULT NULL COMMENT '买家好评数量总和（冗余）',
    sort                   tinyint(3) unsigned DEFAULT NULL COMMENT '排序序号',

    title                  varchar(255)        DEFAULT NULL COMMENT '标题',
    attribute_template_id  bigint(20) unsigned DEFAULT NULL COMMENT '属性模版id',
    specifications         varchar(2500)       DEFAULT NULL COMMENT '全部属性，使用JSON格式表示',

    gmt_create             datetime            DEFAULT NULL COMMENT '数据创建时间',
    gmt_modified           datetime            DEFAULT NULL COMMENT '数据最后修改时间',
    PRIMARY KEY (id)
) DEFAULT CHARSET = utf8mb4 COMMENT ='SKU（Stock Keeping Unit）';