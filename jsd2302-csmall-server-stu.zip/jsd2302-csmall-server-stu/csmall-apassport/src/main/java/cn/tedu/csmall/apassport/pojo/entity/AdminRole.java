package cn.tedu.csmall.apassport.pojo.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@TableName("ams_role")
public class AdminRole implements Serializable {

    @TableId(type = IdType.AUTO)
    private Long id;
    private Long adminId;
    private Long roleId;
//    private String name;
//    private String description;
//    private int sort;
    private LocalDateTime gmtCreate;
    private LocalDateTime gmtModified;
}
