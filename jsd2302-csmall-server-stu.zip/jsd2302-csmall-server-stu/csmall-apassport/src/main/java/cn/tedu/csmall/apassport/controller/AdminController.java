package cn.tedu.csmall.apassport.controller;

import cn.tedu.csmall.apassport.mapper.RoleMapper;
import cn.tedu.csmall.apassport.pojo.param.AdminAddNewParam;
import cn.tedu.csmall.apassport.service.IAdminService;
import cn.tedu.csmall.apassport.web.JsonResult;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import  cn.tedu.csmall.apassport.pojo.entity.Role;

import java.util.List;

@RestController
@Api(tags = "管理用户")
@RequestMapping("/admin/")
public class AdminController {



    @Autowired
    IAdminService adminService;

    @Autowired
    RoleMapper roleMapper;
    @ApiOperationSupport(order = 400)
    @ApiOperation("用户角色")
    @GetMapping("roles")
    public JsonResult add(){

     List<Role> list =   roleMapper.list();
        return     JsonResult.ok(list);
    }


    @ApiOperationSupport(order = 400)
    @ApiOperation("增加用户")
    @PostMapping("add")
    public JsonResult add( AdminAddNewParam adminAddNewParam){
        System.out.println("adminAddNewParam==="+adminAddNewParam);
      adminService.batchNewAdmin(adminAddNewParam);
    return     JsonResult.ok("增加成功");
  }

    @ApiOperationSupport(order = 500)
    @ApiOperation("删除用户")
    @PostMapping("delete")
    public JsonResult delete(Long id){


        return     JsonResult.ok("删除成功");
    }


}
