package cn.tedu.csmall.apassport.mapper;

import cn.tedu.csmall.apassport.pojo.entity.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminMapper extends BaseMapper<Admin> {
}
