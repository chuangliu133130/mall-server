package cn.tedu.csmall.apassport.pojo.param;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class AdminAddNewParam {
    String username;
    String password;
    String nickname;
    String avatar;

    String phone;
    String email;
    String description;
    Long enable;

    Long[] roleIds;

}
