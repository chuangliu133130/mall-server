package cn.tedu.csmall.apassport.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("ams_admin")
public class Admin {
    @TableId(type = IdType.AUTO)
    Long id;
    String username;
    String password;
    String nickname;
    String avatar;

    String phone;
    String email;
    String description;
    Long enable;
    String last_login_ip;

    Long login_count;
    private LocalDateTime gmtCreate;
    private LocalDateTime gmtModified;
    private LocalDateTime gmtLastLogin;


}
