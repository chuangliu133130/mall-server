package cn.tedu.csmall.apassport.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@TableName("ams_rol")
public class Role implements Serializable {

    @TableId(type = IdType.AUTO)
    int id;
    String name;
    String description;
    int sort;
    private LocalDateTime gmtCreate;
    private LocalDateTime gmtModified;


}
