package cn.tedu.csmall.apassport.service.AdminServiceImp;
import cn.tedu.csmall.apassport.mapper.AdminMapper;
import cn.tedu.csmall.apassport.mapper.AdminRoleMapper;
import cn.tedu.csmall.apassport.pojo.entity.Admin;
import cn.tedu.csmall.apassport.pojo.entity.AdminRole;
import cn.tedu.csmall.apassport.pojo.param.AdminAddNewParam;
import cn.tedu.csmall.apassport.service.IAdminService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
@Slf4j
@Service
public class AdminServiceImp implements IAdminService{
    @Autowired
    AdminMapper adminMapper;
    @Autowired
    AdminRoleMapper adminRoleMapper;

    @Override
    public void addNewAdmin(AdminAddNewParam adminAddNewParam) {
        Admin admin = new Admin();
        BeanUtils.copyProperties(adminAddNewParam ,admin);
        adminMapper.insert(admin);;
    }

    @Override
    public void batchNewAdmin(AdminAddNewParam adminAddNewParam) {
        Admin admin = new Admin();
        BeanUtils.copyProperties(adminAddNewParam ,admin);
        log.debug("\n new admin ===\n" + admin);
        adminMapper.insert(admin);
        log.debug("\n has insert admin ===\n" + admin);

        Long[] roleIds = adminAddNewParam.getRoleIds();

        List<AdminRole> alist = new ArrayList<>();
        for (int i = 0; i < adminAddNewParam.getRoleIds().length; i++) {
            log.debug("AdminRole====" + i+1);
            AdminRole adminRole = new AdminRole();
            adminRole.setAdminId( admin.getId() );
            Long roleid =  roleIds[i];
            adminRole.setRoleId(roleid);
            adminRole.setGmtCreate(LocalDateTime.now());
            adminRole.setGmtModified(LocalDateTime.now());
            alist.add(adminRole);

        }
        adminRoleMapper.insertBatch(alist);

    }


}
