package cn.tedu.csmall.apassport.service;

import cn.tedu.csmall.apassport.pojo.entity.Admin;
import cn.tedu.csmall.apassport.pojo.param.AdminAddNewParam;
import cn.tedu.csmall.apassport.pojo.vo.AlbumListItemVO;
import cn.tedu.csmall.apassport.pojo.vo.AlbumStandardVO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface IAdminService  {
    void addNewAdmin(AdminAddNewParam adminAddNewParam);
    void batchNewAdmin(AdminAddNewParam adminAddNewParam);

}
