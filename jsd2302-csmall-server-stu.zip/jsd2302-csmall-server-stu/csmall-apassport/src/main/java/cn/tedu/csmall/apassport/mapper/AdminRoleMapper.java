package cn.tedu.csmall.apassport.mapper;

import cn.tedu.csmall.apassport.pojo.entity.AdminRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AdminRoleMapper extends BaseMapper<AdminRole> {
    int insertBatch( List<AdminRole> adminRolesList);
}
