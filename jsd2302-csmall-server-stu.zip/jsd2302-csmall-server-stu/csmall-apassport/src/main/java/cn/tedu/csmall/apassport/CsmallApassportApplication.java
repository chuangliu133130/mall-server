package cn.tedu.csmall.apassport;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsmallApassportApplication {

    public static void main(String[] args) {
        SpringApplication.run(CsmallApassportApplication.class, args);


    }

}
