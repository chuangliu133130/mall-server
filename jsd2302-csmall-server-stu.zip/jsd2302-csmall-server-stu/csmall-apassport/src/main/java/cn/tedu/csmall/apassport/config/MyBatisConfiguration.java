package cn.tedu.csmall.apassport.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan("cn.tedu.csmall.apassport.mapper")
public class MyBatisConfiguration {
}
