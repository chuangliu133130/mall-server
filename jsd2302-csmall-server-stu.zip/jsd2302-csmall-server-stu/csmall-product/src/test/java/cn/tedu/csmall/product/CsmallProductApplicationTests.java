package cn.tedu.csmall.product;

import cn.tedu.csmall.product.mapper.CategoryMapper;
import cn.tedu.csmall.product.pojo.param.AlbumAddNewParam;
import cn.tedu.csmall.product.pojo.param.BrandNewParam;
import cn.tedu.csmall.product.pojo.param.CategoryParam;
import cn.tedu.csmall.product.service.IAlbumService;
import cn.tedu.csmall.product.service.IBrandService;
import cn.tedu.csmall.product.service.ICategoryService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Validated
@SpringBootTest
class CsmallProductApplicationTests {
@Autowired
    IBrandService brandService;
@Autowired
    ICategoryService iCategoryService;
@Autowired
    IAlbumService iAlbumService;
    @Test
    void iAlbumService() {
        AlbumAddNewParam albumAddNewParam = new AlbumAddNewParam();
        albumAddNewParam.setName("aaalbum");
        iAlbumService.addNew(albumAddNewParam);
    }
    @Test
    void categoryService() {
        CategoryParam categoryParam = new CategoryParam();
        categoryParam.setName("cccategory2222");
        iCategoryService.addNew(categoryParam);
    }
    @Test
    void brand() {
        BrandNewParam brandNewParam = new BrandNewParam();
        brandNewParam.setName("aaa222");
        brandService.addNew(brandNewParam);
    }
    @Test
    void contextLoads() {
    }

}
