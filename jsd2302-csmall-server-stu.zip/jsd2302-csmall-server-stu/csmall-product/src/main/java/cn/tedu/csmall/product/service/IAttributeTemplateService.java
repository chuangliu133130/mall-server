package cn.tedu.csmall.product.service;

import cn.tedu.csmall.product.pojo.entity.AttributeTemplate;
import cn.tedu.csmall.product.pojo.param.AlbumUpdateParam;
import cn.tedu.csmall.product.pojo.param.AttributeTemplateAddNewParam;
import cn.tedu.csmall.product.pojo.param.AttributeUpdateParam;
import cn.tedu.csmall.product.pojo.vo.PageData;

public interface IAttributeTemplateService {
    void addNew(AttributeTemplateAddNewParam attributeTemplateAddNewParam);
    void deleteById(Long id );
    void updateInfoById(Long id,  AttributeUpdateParam attributeUpdateParam);

    PageData<AttributeTemplate> list(Integer page);
}
