package cn.tedu.csmall.product.controller;

import cn.tedu.csmall.product.pojo.entity.Brand;
import cn.tedu.csmall.product.pojo.param.AttributeTemplateAddNewParam;
import cn.tedu.csmall.product.pojo.param.BrandNewParam;
import cn.tedu.csmall.product.pojo.param.BrandUpdateParam;
import cn.tedu.csmall.product.service.IBrandService;
import cn.tedu.csmall.product.web.JsonResult;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.constraints.Range;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/brand")
@Api(tags = "07. 品牌管理模块")
@Slf4j
@Validated
public class BrandController {
    @Autowired
    IBrandService brandService;

    @PostMapping("/add-new")
    @ApiOperation("添加品牌")
    @ApiOperationSupport(order = 100)
    public String addNew(BrandNewParam brandNewParam) {
        brandService.addNew(brandNewParam);
        return "添加成功！";
    }

    @PostMapping("/delete")
    @ApiOperation("根据品牌id删除品牌")
    @ApiOperationSupport(order = 200)
    public JsonResult delete(@Range(min = 1 ,message = "id>1")  @RequestParam Long id){

        brandService.deleteById(id);
        return JsonResult.ok();
    }

    @PostMapping("/update")
    @ApiOperation("修改品牌")
    @ApiOperationSupport(order = 500)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id",required = true,example = "1" ,value = "name")
    })
    public JsonResult add(@RequestParam @Range(min = 1,message = "id>1") Long id, @Valid BrandUpdateParam brandUpdateParam){

        Brand brand = new Brand();
        BeanUtils.copyProperties(brandUpdateParam ,brand);
        brand.setId(id);
        brandService.updateInfoById(id,brandUpdateParam);
        return JsonResult.ok();
    }

}
