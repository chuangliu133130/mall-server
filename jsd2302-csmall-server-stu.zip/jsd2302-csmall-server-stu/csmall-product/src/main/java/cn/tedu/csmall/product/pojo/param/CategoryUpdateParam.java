package cn.tedu.csmall.product.pojo.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
@Data
public class CategoryUpdateParam implements Serializable {

    @NotNull(message = "请输入修改类别名字")
    @ApiModelProperty(value = "name" ,required = true, example = "aeb")
    private String name;
    @NotNull(message = "请输入关键词")
    private String keywords;
    @NotNull(message = "请输入种类")
    private int sort;
    @NotNull(message = "请输入icon")
    private String icon;
}
