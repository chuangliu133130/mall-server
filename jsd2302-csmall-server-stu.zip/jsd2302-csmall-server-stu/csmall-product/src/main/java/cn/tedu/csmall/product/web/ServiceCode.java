package cn.tedu.csmall.product.web;

import lombok.Data;


public enum ServiceCode {
    ok(20000),
    ERR_BAD_REQUEST(40000),
    ERR_CONFLICT(40900),
    ERR_UNKNOWN(99999)
            ;


    private Integer value;

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    ServiceCode(Integer value) {
        this.value = value;
    }
}
