package cn.tedu.csmall.product.mapper;

import cn.tedu.csmall.product.pojo.entity.PmsCategoryAttributeTemplate;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface PmsCategoryAttributeTemplateMapper extends BaseMapper<PmsCategoryAttributeTemplate> {



}
