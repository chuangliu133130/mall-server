package cn.tedu.csmall.product.controller;

import cn.tedu.csmall.product.pojo.entity.AttributeTemplate;
import cn.tedu.csmall.product.pojo.param.AlbumUpdateParam;
import cn.tedu.csmall.product.pojo.param.AttributeTemplateAddNewParam;
import cn.tedu.csmall.product.pojo.param.AttributeUpdateParam;
import cn.tedu.csmall.product.pojo.vo.AlbumListItemVO;
import cn.tedu.csmall.product.pojo.vo.PageData;
import cn.tedu.csmall.product.service.IAttributeTemplateService;
import cn.tedu.csmall.product.web.JsonResult;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
@Slf4j
@RestController
@RequestMapping("/attribute-template")
@Api(tags = "06. 属性模板管理模块")
public class AttributeTemplateController {

    @Autowired
    private IAttributeTemplateService iAttributeTemplateService;

    @GetMapping("/list")
    @ApiOperation("查看属性模板")
    @ApiOperationSupport(order = 700)
    public JsonResult list(Integer page){
        if (page == null || page < 1) {
        page = 1;
    }
        PageData<AttributeTemplate> pageData = iAttributeTemplateService.list(page);
        System.out.println("IAttributeTemplateService===");
        System.out.println( JsonResult.ok(pageData));
        return JsonResult.ok(pageData);
    }

    // http://localhost:8080/attribute-template/add-new
    @PostMapping("/add-new")
    @ApiOperation("添加属性模板")
    @ApiOperationSupport(order = 100)
    public JsonResult addNew(AttributeTemplateAddNewParam attributeTemplateAddNewParam) {
        iAttributeTemplateService.addNew(attributeTemplateAddNewParam);
        return JsonResult.ok("添加属性模版成功");
    }

    @PostMapping("/delete")
    @ApiOperation("删除属性")
    @ApiOperationSupport(order = 200)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id",value = "属性id", required = true, dataType = "long"),
    })
    public JsonResult  delete(@Range(min = 1,message = "id > 1") @RequestParam Long id){
        iAttributeTemplateService.deleteById(id);
        return JsonResult.ok();
    }

    @PostMapping("/update")
    @ApiOperation("修改属性")
    @ApiOperationSupport(order = 300)

    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "属性ID", required = true, dataType = "long")
    })
    public JsonResult updateInfoById(@RequestParam @Range(min = 1, message = "请提交有效的相册ID值！") Long id,
                                     @Valid AttributeUpdateParam attributeUpdateParam) {
        log.debug("开始处理【修改相册详情】的业务，参数：{}", attributeUpdateParam);
        iAttributeTemplateService.updateInfoById(id, attributeUpdateParam);
        return JsonResult.ok();
    }
}
