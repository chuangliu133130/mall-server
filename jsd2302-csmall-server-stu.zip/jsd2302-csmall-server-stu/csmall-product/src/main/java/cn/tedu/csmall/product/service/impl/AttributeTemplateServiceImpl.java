package cn.tedu.csmall.product.service.impl;

import cn.tedu.csmall.product.ex.ServiceException;
import cn.tedu.csmall.product.mapper.AttributeTemplateMapper;
import cn.tedu.csmall.product.mapper.PmsCategoryAttributeTemplateMapper;
import cn.tedu.csmall.product.pojo.entity.AttributeTemplate;
import cn.tedu.csmall.product.pojo.entity.PmsCategoryAttributeTemplate;
import cn.tedu.csmall.product.pojo.param.AttributeTemplateAddNewParam;
import cn.tedu.csmall.product.pojo.param.AttributeUpdateParam;
import cn.tedu.csmall.product.pojo.vo.AlbumListItemVO;
import cn.tedu.csmall.product.pojo.vo.PageData;
import cn.tedu.csmall.product.service.IAttributeTemplateService;
import cn.tedu.csmall.product.util.PageInfoToPageDataConverter;
import cn.tedu.csmall.product.web.ServiceCode;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
public class AttributeTemplateServiceImpl implements IAttributeTemplateService {

    @Autowired
    private AttributeTemplateMapper attributeTemplateMapper;

    @Autowired
    private PmsCategoryAttributeTemplateMapper pmsCategoryAttributeTemplateMapper;

    @Override
    public void addNew(AttributeTemplateAddNewParam attributeTemplateAddNewParam) {
        log.debug("开始处理【添加属性模板】的业务，参数：{}", attributeTemplateAddNewParam);
        // 检查属性模板名称是否被占用，如果被占用，则抛出异常
        QueryWrapper<AttributeTemplate> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("name", attributeTemplateAddNewParam.getName()); // name='参数中的属性模板名称'
        int countByName = attributeTemplateMapper.selectCount(queryWrapper);
        log.debug("根据属性模板名称统计匹配的属性模板数量，结果：{}", countByName);
        if (countByName > 0) {
            String message = "添加属性模板失败，属性模板名称已经被占用！";
            log.warn(message);
            throw new ServiceException(ServiceCode.ERR_UNKNOWN,message);
        }

        // 将属性模板数据写入到数据库中
        AttributeTemplate attributeTemplate = new AttributeTemplate();
        BeanUtils.copyProperties(attributeTemplateAddNewParam, attributeTemplate);
        attributeTemplate.setGmtCreate(LocalDateTime.now());
        attributeTemplate.setGmtModified(LocalDateTime.now());
        attributeTemplateMapper.insert(attributeTemplate);
        log.debug("将新的属性模板数据写入到数据库，完成！");
    }

    @Override
    public void deleteById(Long id) {
        log.debug("删除属性参数id={}" ,id);
        if(id<1){
            throw new ServiceException( ServiceCode.ERR_UNKNOWN,id+"属性需要大于0");
        }
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("id",id);
        int count = attributeTemplateMapper.selectCount(queryWrapper);
        if(count ==0){
            throw new ServiceException( ServiceCode.ERR_UNKNOWN,id+"属性不存在");
        }


        // 检查是否有关联到了，如果存在，则抛出异常
        QueryWrapper<PmsCategoryAttributeTemplate> queryWrapper2 = new QueryWrapper<>();
        queryWrapper2.eq("attribute_template_id", id);
        int attribute_template_id = pmsCategoryAttributeTemplateMapper.selectCount(queryWrapper2);
        log.debug("根据 attribute_template_id 统计匹配的数量，结果：{}", attribute_template_id);
        if (attribute_template_id > 0) {
            String message = "删除属性模版失败，仍有关联到此数据！";
            log.warn(message);
            throw new ServiceException(ServiceCode.ERR_CONFLICT, message);
        }


        attributeTemplateMapper.deleteById(id);


    }

    @Override
    public void updateInfoById(Long id, AttributeUpdateParam attributeUpdateParam) {

        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("id",id);
        int count = attributeTemplateMapper.selectCount(queryWrapper);
        if(count ==0){
            throw new ServiceException( ServiceCode.ERR_UNKNOWN, id+"  属性不存在");
        }

        AttributeTemplate attributeTemplate = new AttributeTemplate();
        BeanUtils.copyProperties(attributeUpdateParam ,attributeTemplate);
        attributeTemplate.setId(id);
        attributeTemplateMapper.updateById(attributeTemplate);

    }

    @Override
    public PageData<AttributeTemplate> list(Integer page) {
        Integer pageNum = page;
        Integer pageSize = 5;

        PageHelper.startPage(pageNum, pageSize);
        List<AttributeTemplate> list = attributeTemplateMapper.list();
        PageInfo<AttributeTemplate> pageInfo = new PageInfo<>(list);
        PageData<AttributeTemplate> pageData = PageInfoToPageDataConverter.convert(pageInfo);
        log.debug("查询完成，即将返回：{}", pageData);
        return pageData;

    }

}
