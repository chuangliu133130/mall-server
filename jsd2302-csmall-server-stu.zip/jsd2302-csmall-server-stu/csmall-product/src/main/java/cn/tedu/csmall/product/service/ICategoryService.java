package cn.tedu.csmall.product.service;

import cn.tedu.csmall.product.pojo.param.AttributeUpdateParam;
import cn.tedu.csmall.product.pojo.param.CategoryParam;
import cn.tedu.csmall.product.pojo.param.CategoryUpdateParam;

public interface ICategoryService {
    void addNew(CategoryParam categoryParam);
    void deleteById(Long id );
    void updateInfoById(Long id,  CategoryUpdateParam categoryUpdateParam);

}
