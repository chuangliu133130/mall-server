package cn.tedu.csmall.product.service.impl;

import cn.tedu.csmall.product.ex.ServiceException;
import cn.tedu.csmall.product.mapper.BrandMapper;
import cn.tedu.csmall.product.mapper.PmsBrandCategoryMapper;
import cn.tedu.csmall.product.pojo.entity.Album;
import cn.tedu.csmall.product.pojo.entity.Brand;
import cn.tedu.csmall.product.pojo.entity.Picture;
import cn.tedu.csmall.product.pojo.entity.PmsBrandCategory;
import cn.tedu.csmall.product.pojo.param.BrandNewParam;
import cn.tedu.csmall.product.pojo.param.BrandUpdateParam;
import cn.tedu.csmall.product.service.IBrandService;
import cn.tedu.csmall.product.web.ServiceCode;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@Slf4j

public class BrandServiceImp implements IBrandService {
    @Autowired
    BrandMapper brandMapper;
    @Autowired
    PmsBrandCategoryMapper pmsBrandCategoryMapper;

    @Override
    public void addNew(BrandNewParam brandNewParam) {

        log.debug("开始处理【添加品牌】的业务，参数：{}", brandNewParam);
        // 检查品牌名称是否被占用，如果被占用，则抛出异常
        QueryWrapper<Brand> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("name", brandNewParam.getName()); // name='参数中的品牌名称'
        int countByName = brandMapper.selectCount(queryWrapper);
        log.debug("根据品牌名称统计匹配的品牌数量，结果：{}", countByName);
        if (countByName > 0) {
            String message = "添加品牌失败，品牌名称已经被占用！";
            log.warn(message);
            throw new ServiceException(ServiceCode.ERR_UNKNOWN, message);
        }

        // 将品牌数据写入到数据库中
        Brand brand = new Brand();
        BeanUtils.copyProperties(brandNewParam, brand);
        brand.setGmtCreate(LocalDateTime.now());
        brand.setGmtModified(LocalDateTime.now());
        brandMapper.insert(brand);
        log.debug("将新的品牌数据写入到数据库，完成！");

    }

    @Override
    public void deleteById(Long id) {
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("id", id);
        int count = brandMapper.selectCount(queryWrapper);
        if (count == 0) {
            throw new ServiceException(ServiceCode.ERR_UNKNOWN, "品牌不存在");

        }

        QueryWrapper<PmsBrandCategory> queryWrapper2 = new QueryWrapper<>();
        queryWrapper2.eq("brand_id", id);
        int countByBranId = pmsBrandCategoryMapper.selectCount(queryWrapper2);
        log.debug("根据品牌ID统计匹配的图片数量，结果：{}", countByBranId);
        if (countByBranId > 0) {
            String message = "删除失败，仍有关联！";
            log.warn(message);
            throw new ServiceException(ServiceCode.ERR_CONFLICT, message);
        }




        brandMapper.deleteById(id);
        log.debug("删除品牌完成！");

    }

    @Override
    public void updateInfoById(Long id, BrandUpdateParam brandUpdateParam) {
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("id", id);
        int count = brandMapper.selectCount(queryWrapper);
        if (count == 0) {
            throw new ServiceException(ServiceCode.ERR_UNKNOWN, id + "  品牌不存在");
        }
        Brand brand = new Brand();
        BeanUtils.copyProperties(brandUpdateParam, brand);
        brand.setId(id);
        brandMapper.updateById(brand);
    }
}
