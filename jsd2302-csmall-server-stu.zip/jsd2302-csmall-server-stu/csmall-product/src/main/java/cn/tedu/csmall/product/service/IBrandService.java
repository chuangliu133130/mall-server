package cn.tedu.csmall.product.service;

import cn.tedu.csmall.product.pojo.param.AlbumAddNewParam;
import cn.tedu.csmall.product.pojo.param.AttributeUpdateParam;
import cn.tedu.csmall.product.pojo.param.BrandNewParam;
import cn.tedu.csmall.product.pojo.param.BrandUpdateParam;

public interface IBrandService {
    void addNew(BrandNewParam brandNewParam);
    void deleteById(Long id );
    void updateInfoById(Long id,  BrandUpdateParam brandUpdateParam);

}
