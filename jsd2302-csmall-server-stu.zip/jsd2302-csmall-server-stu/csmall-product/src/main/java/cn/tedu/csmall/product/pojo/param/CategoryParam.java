package cn.tedu.csmall.product.pojo.param;


import lombok.Data;

import java.io.Serializable;

@Data
public class CategoryParam implements Serializable {
    private String name;
    private String icon;
    private Long parentId;
    private Integer depth;
    private String keywords;
    private Integer sort;
    private Integer enable;
    private Integer isParent;
    private Integer isDisplay;
}
