package cn.tedu.csmall.product.pojo.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
@Data
public class BrandUpdateParam  implements Serializable {
    @NotNull(message = "修改品牌失败,品牌名字必须不为空")
    @ApiModelProperty(value = "品牌名字" ,required = true,example = "修改品牌啊")
    private String name;

    @NotNull(message = "请修改品牌拼音")
    @ApiModelProperty(value = "品牌拼音" ,required = true,example = "shuxingpiny")
    private String pinyin;

    @NotNull(message = "请修改品牌logo")
    @ApiModelProperty(value = "logo" , required = true,example = "logo")
    private String logo;

    @NotNull(message = "请修改 品牌描述")
    @ApiModelProperty(value = "des" ,required = true,example = "des")
    private String description;

    @NotNull(message = "请修改关键词为空")
    private String keywords;
    private String sort;

}
