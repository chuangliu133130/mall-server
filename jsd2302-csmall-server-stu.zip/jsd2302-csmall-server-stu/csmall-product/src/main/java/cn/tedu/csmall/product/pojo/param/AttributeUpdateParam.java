package cn.tedu.csmall.product.pojo.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.security.PrivateKey;
@Data
public class AttributeUpdateParam  implements Serializable {
    @NotNull(message = "修改属性失败,属性名字必须不为空")
    @ApiModelProperty(value = "属性名字" ,required = true,example = "修改属性啊")
    private String name;

    @NotNull(message = "请修改属性拼音")
    @ApiModelProperty(value = "属性拼音" ,required = true,example = "shuxingpiny")
    private String pinyin;

    @NotNull(message = "请修改关键词为空")
    private String keywords;
    @NotNull(message = "请修改序号")
    private String sort;

}
