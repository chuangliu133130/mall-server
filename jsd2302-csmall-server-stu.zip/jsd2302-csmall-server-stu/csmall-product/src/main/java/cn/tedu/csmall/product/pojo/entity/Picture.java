package cn.tedu.csmall.product.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDateTime;

@TableName("pms_picture")
public class Picture {
   @TableId(type = IdType.AUTO)
    private  Long id;
    private  Long album_Id;

    private  String url;
    private  String discription;

    private  int width;
    private  int height;
    private  int isCover;
    private  short sort;

    private LocalDateTime gmtCreate;
    private LocalDateTime gmtModified;
}
